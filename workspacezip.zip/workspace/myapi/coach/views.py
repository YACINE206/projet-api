from django.shortcuts import render

# Create your views here.
from rest_framework.response import Response
from rest_framework.decorators import api_view
from .open_ai_service import open_ia_response
@api_view(['POST'])
def generate_workout_plan(request):

    user_goals = request.data.get('goal')
    prompt = f"Génère un plan d'entraînement pour un objectif : {user_goals}."
    return Response(open_ia_response(prompt))

@api_view(['GET'])
def stretching_guide(request):

    response = open_ia_response("Donne un exercice d'étirement rapide pour améliorer la flexibilité.")
    return Response(response)

@api_view(['GET'])
def hydration_reminder(request):

    response = open_ia_response("Explique pourquoi il est important de rester hydraté et combien d'eau boire par jour.")
    return Response(response)

@api_view(['GET'])
def quick_warmup(request):

    response = open_ia_response("Propose une routine d'échauffement rapide avant un entraînement.")
    return Response(response)

@api_view(['POST'])
def log_meal(request):

    meal = request.data.get('meal')
    prompt = f"Analyse nutritionnelle du repas : {meal}."
    return Response(open_ia_response(prompt))
