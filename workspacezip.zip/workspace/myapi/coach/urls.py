from .views import *
from django.contrib import admin
from django.urls import path
from django.urls import include

urlpatterns = [
path('workout-plan', generate_workout_plan),
path('stretch-guide', stretching_guide),
path('hydration-reminder', hydration_reminder),
path('quick-warmup', quick_warmup),
path('log-meal', log_meal),
]