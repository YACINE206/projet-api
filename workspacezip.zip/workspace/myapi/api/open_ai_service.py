import openai

openai.api_key = "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"
openai.api_base = "https://openrouter.ai/api/v1"

def open_ia_response(prompt):
    response = openai.ChatCompletion.create(
        model="openai/gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}]
    )
    return response["choices"][0]["message"]["content"]